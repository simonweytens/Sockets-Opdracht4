struct {
    int IO;
    int period;
} typedef t_data;
